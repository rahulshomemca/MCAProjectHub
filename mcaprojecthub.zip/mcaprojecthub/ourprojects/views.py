from django.shortcuts import render
from ourprojects.models import *

# Create your views here.

def index(request):
    profile =  Profile.objects.all()
    iot = Project.objects.filter(catagory="iot").order_by('-id')[:3]
    android = Project.objects.filter(catagory="android").order_by('-id')[:3]
    webapp = Project.objects.filter(catagory="webapp").order_by('-id')[:3]
    return render(request, "index.html", {'profile':profile,'android':android, 'webapp':webapp, 'iot':iot})

def profile(request,id):
    person = Profile.objects.get(id=id)
    return render(request, "profile.html", {'person':person})

def catagory(request,catagory):
    cata = catagory
    catagories = Project.objects.filter(catagory=catagory)
    return render(request, "catagory.html", {'catagories':catagories,'cata':cata})

def project(request,id):
    catagories = Project.objects.get(id=id)
    return render(request, "project.html", {'cat':catagories})


