from django.db import models

from django.db import models

class Profile(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30, default='')
    designation = models.CharField(max_length=50, default='')
    description = models.TextField(default='')
    email = models.EmailField(default='')
    github = models.CharField(max_length=500, default='')
    facebook = models.CharField(max_length=500, default='')
    twitter = models.CharField(max_length=500, default='')
    instagram = models.CharField(max_length=500, default='')
    linkedin = models.CharField(max_length=500, default='')
    image = models.ImageField(upload_to="images/profile")

    def __str__(self):
        return self.name

class Project(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30, default='')
    description = models.TextField(default='')
    catagory = models.CharField(max_length=256, choices=[('iot', 'iot'), ('android', 'android'), ('webapp', 'webapp')])
    author = models.ForeignKey(Profile, on_delete=models.CASCADE)
    source = models.CharField(max_length=500, default='')
    apk = models.CharField(max_length=500, default='')
    link = models.CharField(max_length=500, default='')
    image = models.ImageField(upload_to="images/profile")

    def __str__(self):
        return self.name
