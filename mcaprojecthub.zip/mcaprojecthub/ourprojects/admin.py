from django.contrib import admin
from ourprojects.models import *
# Register your models here.
admin.site.register(Profile)
admin.site.register(Project)