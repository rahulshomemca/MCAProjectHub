from django.contrib import admin
from django.urls import path
from ourprojects.views import *

urlpatterns = [
    path('', index, name="index"),
    path('profile/<id>', profile, name="profile"),
    path('catagory/<catagory>', catagory, name="catagory"),
    path('project/<id>', project, name="project"),
]
