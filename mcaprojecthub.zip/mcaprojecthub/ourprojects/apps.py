from django.apps import AppConfig


class OurprojectsConfig(AppConfig):
    name = 'ourprojects'
